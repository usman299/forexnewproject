<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="sp_site_card">
                <div class="card-header">
                    <form action="" method="get" class="row justify-content-md-end g-3">
                        <div class="col-auto">
                            <input type="text" name="trx" class="form-control me-2" placeholder="transaction id">
                        </div>
                        <div class="col-auto">
                            <input type="date" class="form-control me-3" placeholder="Search User" name="date">
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn sp_theme_btn"><?php echo e(__('Search')); ?></button>
                        </div>
                    </form>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table sp_site_table">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Trx')); ?></th>
                                    <th><?php echo e(__('User')); ?></th>
                                    <th><?php echo e(__('Gateway')); ?></th>
                                    <th><?php echo e(__('Amount')); ?></th>
                                    <th><?php echo e(__('Currency')); ?></th>
                                    <th><?php echo e(__('Charge')); ?></th>
                                    <th><?php echo e(__('Payment Date')); ?></th>
                                    <th><?php echo e(__('Plan Expired At')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td data-caption="<?php echo e(__('Trx')); ?>"><?php echo e($investment->trx); ?></td>
                                        <td data-caption="<?php echo e(__('User')); ?>">
                                            <?php echo e($investment->user->username); ?></td>
                                        <td data-caption="<?php echo e(__('Gateway')); ?>">

                                            <?php if($investment->gateway_id == null): ?>
                                                <?php echo e(__('Invest Using Balance')); ?>

                                            <?php else: ?>
                                                <?php echo e(optional($investment->gateway)->name ?? 'Account Transfer'); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td data-caption="<?php echo e(__('Amount')); ?>"><?php echo e(Config::formatter($investment->amount)); ?></td>
                                        <td data-caption="<?php echo e(__('Currency')); ?>">
                                            <?php if($investment->gateway_id == null): ?>
                                                <?php echo e(Config::config()->currency); ?>

                                            <?php else: ?>
                                                <?php echo e(optional($investment->gateway)->parameter->gateway_currency ?? ''); ?>

                                            <?php endif; ?>

                                        </td>
                                        <td data-caption="<?php echo e(__('Charge')); ?>">
                                            <?php echo e(Config::formatter($investment->charge)); ?></td>

                                        <td data-caption="<?php echo e(__('Payment Date')); ?>">
                                            <?php echo e($investment->created_at->format('Y-m-d')); ?>

                                        </td>
                                        <td data-caption="<?php echo e(__('Plan Expired At')); ?>">
                                            <?php echo e($investment->plan_expired_at); ?>

                                        </td>
                                        <td>
                                            <?php if($investment->status == 2): ?>
                                                <span class="sp_badge sp_badge_warning"><?php echo e(__('Pending')); ?></span>
                                            <?php elseif($investment->status == 1): ?>
                                                <span class="sp_badge sp_badge_success"><?php echo e(__('Accept')); ?></span>
                                            <?php elseif($investment->status == 3): ?>
                                                <span class="sp_badge sp_badge_success"><?php echo e(__('Rejected')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-center" colspan="100%">
                                            <?php echo e(__('No Invest Found')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>



                    </div>
                </div>
                <?php if($investments->hasPages()): ?>
                    <div class="card-footer">
                        <?php echo e($investments->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(Config::theme() . 'layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forex\main\resources\views/frontend/default/user/invest_log.blade.php ENDPATH**/ ?>