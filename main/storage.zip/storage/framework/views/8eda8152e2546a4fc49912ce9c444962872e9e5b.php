


<?php $__env->startSection('element'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header site-card-header d-flex justify-content-between">
                    <div class="card-header-right">
                        <a href="<?php echo e(route('admin.language.index')); ?>" class="btn btn-sm btn-primary"> <i
                                class="fa fa-arrow-left"></i>
                            <?php echo e(__('Back')); ?></a>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs page-link-list border-bottom-0" role="tablist">
                        <li>
                            <a class=" active" data-toggle="tab" href="#general">
                                <i class="las la-home"></i>
                                <?php echo e(__('General Content')); ?>

                            </a>
                        </li>
                        <li>
                            <a data-toggle="tab" href="#frontend">
                                <i class="las la-cloud"></i>
                                <?php echo e(__('Frontend Section Content')); ?>

                            </a>
                        </li>
                    </ul>


                </div>

                <div class="tab-content tabcontent-border">
                    <div class="tab-pane fade show active" id="general" role="tabpanel">
                        <div class="card">

                            <div class="row mt-2">
                                <div class="col-lg-6">
                                    <div class="card-header-left">
                                        <input type="text" name="search" class="form-control form-control-sm" placeholder="Search key" id="search">
                                    </div>
                                </div>
                            </div>


                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table student-data-table language-table" id="translate">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('Key')); ?></th>
                                                <th><?php echo e(__('Value')); ?></th>
                                                <th><?php echo e(__('Action')); ?></th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <form method="POST"
                                                action="<?php echo e(route('admin.language.ajax', request()->lang)); ?>">
                                                <?php echo csrf_field(); ?>

                                                <tr>
                                                    <td>
                                                        <input type="hidden" name="type" value="content">
                                                    </td>
                                                </tr>
                                                <?php $__empty_1 = true; $__currentLoopData = $translators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr class="filt">
                                                        <td class="font-weight-bold white-space-wrap"><?php echo e($key); ?>

                                                        </td>

                                                        <td>
                                                            <input type="hidden" name="key[]"
                                                                value="<?php echo e($key); ?>">
                                                            <textarea name="value[]" class="form-control lang-field"><?php echo e($lang); ?></textarea>

                                                        </td>
                                                        <td>
                                                            <button type="button"
                                                                class="btn btn-sm btn-outline-danger delete"
                                                                data-lang_key="<?php echo e($key); ?>" data-type="content"><i
                                                                    class="fa fa-trash"></i></button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td class="text-center" colspan="100%"><?php echo e(__('No Data Found')); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                                <button class="btn btn-sm btn-primary float-btn">
                                                    <i class="fa fa-spinner"></i>
                                                    <?php echo e(__('Update')); ?>

                                                </button>
                                            </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="tab-pane fade" id="frontend" role="tabpanel">
                        <div class="card">
                            <div class="row mt-2">
                                <div class="col-lg-6">
                                    <div class="card-header-left">
                                        <input type="text" name="search" class="form-control form-control-sm"
                                            placeholder="Search key" id="searchContent">
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table student-data-table language-table" id="translateContent">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('Key')); ?></th>
                                                <th><?php echo e(__('Value')); ?></th>
                                                <th><?php echo e(__('Action')); ?></th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <form method="POST"
                                                action="<?php echo e(route('admin.language.ajax', request()->lang)); ?>">
                                                <?php echo csrf_field(); ?>

                                                <tr>
                                                    <td>
                                                        <input type="hidden" name="type" value="section">
                                                    </td>
                                                </tr>
                                                <?php $__empty_1 = true; $__currentLoopData = $frontendtranslators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr class="filt">
                                                        <td class="font-weight-bold white-space-wrap"><?php echo e($key); ?>

                                                        </td>

                                                        <td>
                                                            <input type="hidden" name="key[]"
                                                                value="<?php echo e($key); ?>">
                                                            <textarea name="value[]" class="form-control lang-field"><?php echo e($lang); ?></textarea>

                                                        </td>
                                                        <td>
                                                            <button type="button"
                                                                class="btn btn-sm btn-outline-danger delete"
                                                                data-lang_key="<?php echo e($key); ?>" data-type="section"><i
                                                                    class="fa fa-trash"></i></button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td class="text-center" colspan="100%"><?php echo e(__('No Data Found')); ?>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                                <button class="btn btn-sm btn-primary float-btn">
                                                    <i class="fa fa-spinner"></i>
                                                    <?php echo e(__('Update')); ?>

                                                </button>


                                            </form>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addmore" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo e(__('Add Translation Data')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for=""><?php echo e(__('Translation Key')); ?></label>
                            <textarea type="text" name="key" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for=""><?php echo e(__('Translation Value')); ?></label>
                            <textarea type="text" name="value" class="form-control"></textarea>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Create')); ?></button>
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="modal fade" id="delete" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('admin.language.key.delete', request()->lang)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo e(__('Delete Language Key')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p><?php echo e(__('Are you sure to delete this key')); ?></p>
                        <input type="hidden" name="key" value="">
                        <input type="hidden" name="type" value="">
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger"><?php echo e(__('Delete')); ?></button>
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('external-css'); ?>
    <link rel="stylesheet" href="<?php echo e(Config::cssLib('backend', 'datatable.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('external-script'); ?>
    <script src="<?php echo e(Config::jsLib('backend', 'datatable.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .float-btn {
            position: fixed;
            bottom: 40px;
            right: 36%;
            width: 200px;
            height: 67px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0, 0.1);
        }

        .language-table .filt td:first-child {
            width: 550px;

        }

        .language-table .filt td:last-child {
            width: 70px;

        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(function() {
            'use strict'


            $('.update').on('click', function() {
                var data = $('#seri').submit();


                return false;
            });


            $('.addmore').on('click', function() {
                const modal = $('#addmore')

                modal.modal('show')
            })

            $('.delete').on('click', function(e) {
                e.preventDefault();
                const modal = $('#delete')

                modal.find('input[name=key]').val($(this).data('lang_key'))
                modal.find('input[name=type]').val($(this).data('type'))

                modal.modal('show')
            })

            $("#search").on("keyup", function() {

                var value = $(this).val().toLowerCase();

                $("#translate .filt").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });


            $("#searchContent").on("keyup", function() {

                var value = $(this).val().toLowerCase();

                $("#translateContent .filt").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });


        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forex\main\resources\views/backend/language/translate.blade.php ENDPATH**/ ?>