<div class="footer">
    <div class="copyright">
        <p>
            <?php echo e(__(Config::config()->copyright)); ?>

        </p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\forex\main\resources\views/backend/layout/footer.blade.php ENDPATH**/ ?>