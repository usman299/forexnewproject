

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="sp_site_card">
                <div class="card-header">
                    <h5><?php echo e(__('Two Factor Authentication')); ?></h5>
                </div>
                <div class="card-body">
                    <div class="card-body">
                        <p><?php echo e(__('Two factor authentication (2FA) strengthens access security by requiring two methods (also referred to as factors) to verify your identity. Two factor authentication protects against phishing, social engineering and password brute force attacks and secures your logins from attackers exploiting weak or stolen credentials.')); ?>

                        </p>

                        <?php echo e(__(' Enter the pin from Google Authenticator app')); ?>:<br /><br />
                        <form class="form-horizontal" action="<?php echo e(route('user.2faVerify')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('one_time_password-code') ? ' has-error' : ''); ?>">
                                <label for="one_time_password" class="control-label"><?php echo e(__('One Time Password')); ?></label>
                                <input id="one_time_password" name="one_time_password" class="form-control col-md-12 mb-3"
                                    type="text" required />
                            </div>
                            <button class="btn sp_theme_btn w-100" type="submit"><?php echo e(__('Authenticate')); ?></button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(Config::theme() . 'layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forex\main\resources\views/frontend/default/user/2fa_verify.blade.php ENDPATH**/ ?>